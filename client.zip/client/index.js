var socket = io("ws://localhost:3030");

socket.on("connect", () => {
  // either with send()

  console.log("client: `hello`");
  socket.send({
    content: "hello",
    customerIdentifier: "04e3c5fc-c42e-4a2e-a7cd-4b512bfab163",
  });

  setTimeout(() => {
    console.log("client: `Sina`");
    socket.send({
      content: "Sina",
      customerIdentifier: "04e3c5fc-c42e-4a2e-a7cd-4b512bfab163",
      previousId: "ON_HELLO",
    });
  }, 1000);

  setTimeout(() => {
    console.log("client: `1993-08-05`");
    socket.send({
      content: "1993-08-05",
      customerIdentifier: "04e3c5fc-c42e-4a2e-a7cd-4b512bfab163",
      previousId: "ON_NAME",
    });
  }, 2000);

  setTimeout(() => {
    console.log("client: `yes`");
    socket.send({
      content: "yes",
      customerIdentifier: "04e3c5fc-c42e-4a2e-a7cd-4b512bfab163",
      previousId: "ON_BIRTH_DATE",
    });
  }, 3000);

  window.send = (content) => {
    socket.send({
      content,
      customerIdentifier: "04e3c5fc-c42e-4a2e-a7cd-4b512bfab163",
    });
    return "sent";
  };
});

// handle the event sent with socket.send()
socket.on("message", (data) => {
  console.log(data);
});
